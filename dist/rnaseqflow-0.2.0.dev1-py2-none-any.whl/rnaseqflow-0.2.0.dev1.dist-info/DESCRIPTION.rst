# jarvis-lab-rnaseq-flow
A Python library to make preprocessing of RNA-seq files more convenient


